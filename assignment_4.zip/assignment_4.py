names_list = ["bob","jimmy","max b", "bernie", "jordan", "future hendrix"]
longestName = " "

for x in names_list:
	if len(x) > len(longestName):
		longestName = x
	else:
		pass

print(longestName)