name = input("What's your name? ")
#the variable "name" is used to hold onto whatever answer the user inputs

print("Hello " + name + "!")
#this print command utilizes the "name" variable so it prints "Hello" before inserting whatever name the user typed in above