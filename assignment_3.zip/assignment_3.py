testNumber = 25
over_under_list = [1,45,32,21,5,17,43,93]

for x in over_under_list:
	if testNumber > x:
		print("over")
	else:
		print("under")