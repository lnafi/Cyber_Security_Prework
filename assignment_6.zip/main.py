#repl.it requires the use of a main.py file, but I wanted to ensure that each individual python file I send it was labeled properly, so I used .replit files to run the actual assignment

#under assignment_6_abstracted.py, I was actually able to abstract the for loops further to make the program more succint, but I did include my original design under assignment_6.py