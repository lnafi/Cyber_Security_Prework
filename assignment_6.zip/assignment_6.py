names_list = ["bob","jimmy","max b", "bernie", "jordan", "future hendrix"]
even_list = []
evenList = []
evenListReunion = []
oddList = []
oddListReunion = []
String = ""

def splitOddEven(n):
	for name in n:
		if len(name) % 2 == 0:
			evenList.append(name)
		else:
			oddList.append(name)
	print(evenList)
	print(oddList)

splitOddEven(names_list)
print(" ")

for evenName in evenList:
	temporaryEvenName = evenName
	temporaryEvenNameList = list(temporaryEvenName)
	del temporaryEvenNameList[0]
	temporaryEvenNameList.insert(0, "b")
	for letter in temporaryEvenNameList:
		String += letter
	evenListReunion.append(String)
	String = ""

print(" ")

for oddName in oddList:
	temporaryOddName = oddName
	temporaryOddNameList = list(temporaryOddName)
	del temporaryOddNameList[(len(temporaryOddName) - 1)]
	temporaryOddNameList.append("c")
	for letter in temporaryOddNameList:
		String += letter
	oddListReunion.append(String)
	String = ""

print(evenListReunion)
print(oddListReunion)
print(" ")
even_list = evenListReunion
print(even_list)