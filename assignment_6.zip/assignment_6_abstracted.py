names_list = ["bob","jimmy","max b", "bernie", "jordan", "future hendrix"]
even_list = []
evenList = []
evenListReunion = []
oddList = []
oddListReunion = []
String = ""

def splitOddEven(n):
	for name in n:
		if len(name) % 2 == 0:
			evenList.append(name)
		else:
			oddList.append(name)
	print(evenList)
	print(oddList)

splitOddEven(names_list)
print(" ")

masterList = evenList + oddList
print(" ")

for name in masterList:
	temporaryName = name
	temporaryNameList = list(temporaryName)
	if len(name) % 2 == 0:
		del temporaryNameList[0]
		temporaryNameList.insert(0, "b")
	else:
		del temporaryNameList[(len(temporaryName) - 1)]
		temporaryNameList.append("c")
	for letter in temporaryNameList:
		String += letter
	if len(String) % 2 == 0:
		evenListReunion.append(String)
	else:
		oddListReunion.append(String)
	String = ""

print(evenListReunion)
print(oddListReunion)
print(" ")
even_list = evenListReunion
print(even_list)