names_list = ["bob","jimmy","max b", "bernie", "jordan", "future hendrix"]
big_name = " "

def extractBiggest(n):
	longestName = " "
	for name in n:
		if len(name) > len(longestName):
			longestName = name
		else:
			pass
	big_name = longestName
	print(big_name)

extractBiggest(names_list)